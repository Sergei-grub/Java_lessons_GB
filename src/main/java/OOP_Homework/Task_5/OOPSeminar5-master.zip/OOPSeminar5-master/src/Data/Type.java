package Data;

public enum Type {
    STUDENT,
    TEACHER
}
